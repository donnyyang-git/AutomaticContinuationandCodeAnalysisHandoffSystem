/*
 *    Copyright 2010-2026 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       https://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.jpetstore.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The Class Cart.
 */
public class Cart implements Serializable {

  /** The serial version uid. */
  private static final long serialVersionUID = 8329559983943337176L;

  /** The item map. */
  private final Map<String, CartItem> itemMap = new ConcurrentHashMap<>();

  /** The item list. */
  private final List<CartItem> itemList = new ArrayList<>();

  /**
   * Gets the cart items.
   *
   * @return the cart items
   */
  public Iterator<CartItem> getCartItems() {
    return itemList.iterator();
  }

  /**
   * Gets the cart item list.
   *
   * @return the cart item list
   */
  public List<CartItem> getCartItemList() {
    return itemList;
  }

  /**
   * Gets the number of items.
   *
   * @return the number of items
   */
  public int getNumberOfItems() {
    return itemList.size();
  }

  /**
   * Gets the all cart items.
   *
   * @return the all cart items
   */
  public Iterator<CartItem> getAllCartItems() {
    return itemList.iterator();
  }

  /**
   * Contains item id.
   *
   * @param itemId
   *          the item id
   *
   * @return true, if successful
   */
  public boolean containsItemId(String itemId) {
    return itemMap.containsKey(itemId);
  }

  /**
   * Adds the item.
   *
   * @param item
   *          the item
   * @param isInStock
   *          the is in stock
   */
  public void addItem(Item item, boolean isInStock) {
    CartItem cartItem = itemMap.get(item.getItemId());
    if (cartItem == null) {
      cartItem = new CartItem();
      cartItem.setItem(item);
      cartItem.setQuantity(0);
      cartItem.setInStock(isInStock);
      itemMap.put(item.getItemId(), cartItem);
      itemList.add(cartItem);
    }
    cartItem.incrementQuantity();
  }

  /**
   * Removes the item by id.
   *
   * @param itemId
   *          the item id
   *
   * @return the item
   */
  public Item removeItemById(String itemId) {
    CartItem cartItem = itemMap.remove(itemId);
    if (cartItem == null) {
      return null;
    } else {
      itemList.remove(cartItem);
      return cartItem.getItem();
    }
  }

  /**
   * Increment quantity by item id.
   *
   * @param itemId
   *          the item id
   */
  public void incrementQuantityByItemId(String itemId) {
    CartItem cartItem = itemMap.get(itemId);
    cartItem.incrementQuantity();
  }

  /**
   * Set quantity by item id.
   *
   * @param itemId
   *          the item id
   * @param quantity
   *          the quantity
   */
  public void setQuantityByItemId(String itemId, int quantity) {
    CartItem cartItem = itemMap.get(itemId);
    cartItem.setQuantity(quantity);
  }

  /**
   * Gets the sub total.
   *
   * @return the sub total
   */
  public BigDecimal getSubTotal() {
    return itemList.stream()
        .map(cartItem -> cartItem.getItem().getListPrice().multiply(new BigDecimal(cartItem.getQuantity())))
        .reduce(BigDecimal.ZERO, BigDecimal::add);
  }

}
